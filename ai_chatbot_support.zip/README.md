# AI Chatbot for Customer Support

A simple Flask-based chatbot for automating customer assistance.