from flask import Flask, request, jsonify

app = Flask(__name__)

responses = {
    "hello": "Hello! How can I assist you today?",
    "help": "Sure, I'm here to help. Please describe your issue.",
    "pricing": "Our pricing details can be found on our website.",
    "bye": "Goodbye! Have a great day!"
}

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message", "").lower()
    response = responses.get(user_input, "I'm sorry, I didn't understand that. Can you rephrase?")
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)